@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "logs" mkdir "logs"
set "LOG=%CD%\logs\startup.log"
> "%LOG%" echo ===== OSRS LIVE DIAGNOSTICS - WINDOWS START =====
if not exist "OSRS-Diagnostics-Client.jar" goto missing_jar
set "OSRS_JAVA_EXE="
for /f "delims=" %%J in ('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FIND-JAVA.ps1"') do set "OSRS_JAVA_EXE=%%J"
if not defined OSRS_JAVA_EXE goto missing_java
>> "%LOG%" echo Java: %OSRS_JAVA_EXE%
echo [1/4] Java wird geprueft ...
"%OSRS_JAVA_EXE%" -version >> "%LOG%" 2>&1
if errorlevel 1 goto failure
echo [2/4] Sichere GitHub-Updates werden geprueft ...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE-OSRS-Diagnostics.ps1" >> "%LOG%" 2>&1
if errorlevel 1 echo HINWEIS: Updatepruefung nicht verfuegbar, lokaler Client wird dennoch gestartet.
echo [3/4] Anwendung wird geprueft ...
"%OSRS_JAVA_EXE%" -Djava.awt.headless=true -jar "OSRS-Diagnostics-Client.jar" --self-test >> "%LOG%" 2>&1
if errorlevel 1 goto failure
echo [4/4] Fenster wird geoeffnet ...
"%OSRS_JAVA_EXE%" -jar "OSRS-Diagnostics-Client.jar" >> "%LOG%" 2>&1
if errorlevel 1 goto failure
exit /b 0
:missing_jar
echo FEHLER: OSRS-Diagnostics-Client.jar fehlt. ZIP vollstaendig entpacken.
goto failure
:missing_java
echo FEHLER: Keine passende Java 17+ Laufzeit gefunden. https://adoptium.net/
goto failure
:failure
echo Start fehlgeschlagen. Log anzeigen:
type "%LOG%"
pause
exit /b 1

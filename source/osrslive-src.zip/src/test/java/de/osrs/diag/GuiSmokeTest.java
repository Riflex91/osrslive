package de.osrs.diag;
import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.lang.reflect.*;
public final class GuiSmokeTest {
    private static JButton find(Component c, String label) {
        if (c instanceof JButton b && b.getText().equals(label)) return b;
        if (c instanceof Container co) for (Component child : co.getComponents()) {
            JButton found = find(child, label);
            if (found != null) return found;
        }
        return null;
    }
    public static void main(String[] args) throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            try {
                Constructor<DiagnosticsApp> ctor=DiagnosticsApp.class.getDeclaredConstructor();
                ctor.setAccessible(true);
                DiagnosticsApp app=ctor.newInstance();
                Field f=DiagnosticsApp.class.getDeclaredField("frame");f.setAccessible(true);
                JFrame frame=(JFrame)f.get(app);
                if(!frame.isShowing()) throw new AssertionError("Window not visible");
                if(find(frame,"Live-Bridge starten") != null) throw new AssertionError("Old RuneLite bridge remains");
                if(find(frame,"Updates prüfen") == null) throw new AssertionError("Update button missing");
                find(frame,"Simulation starten").doClick();
                find(frame,"Grafik ausschalten").doClick();
                find(frame,"Log kopieren").doClick();
                String text=(String)Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
                if(!text.contains("OSRS DIAGNOSTICS | 0.2.1")) throw new AssertionError("Clipboard failed");
                System.out.println("GUI SMOKE PASSED: visible, simulation, rendering, clipboard, update button, bridge removed");
                frame.dispose();
                System.exit(0);
            }catch(Exception ex){ex.printStackTrace();System.exit(1);}
        });
    }
}

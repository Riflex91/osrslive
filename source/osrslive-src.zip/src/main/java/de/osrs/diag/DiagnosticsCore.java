package de.osrs.diag;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/** Pure diagnostic/event layer. No game controls, credentials, or networking. */
public final class DiagnosticsCore {
    public static final String VERSION = "0.2.1";
    public enum Level { DEBUG, INFO, WARN, ERROR }
    public record Entry(long id, Instant at, Level level, String source, String event, String detail) {
        public String toLine() {
            return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS", Locale.ROOT)
                .withZone(ZoneId.systemDefault()).format(at)
                + " [" + level + "] [" + source + "] " + event
                + (detail.isBlank() ? "" : " | " + detail);
        }
    }
    private static final int LIMIT = 10000;
    private static final Pattern SECRET_FIELDS = Pattern.compile("(?i)(bearer\\s+|(?:authorization|token|session|password|passwd|secret|api[_-]?key|cookie)\\s*[:=]\\s*)([^\\s,;]+)");
    private static final Pattern EMAIL = Pattern.compile("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", Pattern.CASE_INSENSITIVE);
    private final ArrayList<Entry> entries = new ArrayList<>();
    private final CopyOnWriteArrayList<Consumer<Entry>> listeners = new CopyOnWriteArrayList<>();
    private final Instant started = Instant.now();
    private long nextId = 1;
    private long dropped = 0;
    private long errorCount = 0;
    private long warningCount = 0;
    private long tickCount = 0;
    private long liveCount = 0;
    private volatile String mode = "NICHT VERBUNDEN";
    private final AtomicBoolean rendering = new AtomicBoolean(true);

    public Entry add(Level level, String source, String event, String detail) {
        Objects.requireNonNull(level);
        Entry entry;
        synchronized (this) {
            entry = new Entry(nextId++, Instant.now(), level, sanitize(source, 32), sanitize(event, 55), sanitize(detail, 480));
            if (entries.size() == LIMIT) { entries.remove(0); dropped++; }
            entries.add(entry);
            if (level == Level.ERROR) errorCount++;
            if (level == Level.WARN) warningCount++;
            if (event.equals("GAME_TICK")) tickCount++;
            if (source.equals("EXTERNAL")) liveCount++;
        }
        for (Consumer<Entry> listener : listeners) {
            try { listener.accept(entry); } catch (RuntimeException ignored) { /* never break diagnostics */ }
        }
        return entry;
    }

    public void addListener(Consumer<Entry> listener) { listeners.add(listener); }
    public synchronized List<Entry> snapshot() { return List.copyOf(entries); }
    public synchronized void clear() {
        entries.clear(); dropped = 0; errorCount = warningCount = tickCount = liveCount = 0;
    }
    public synchronized Stats stats() {
        return new Stats(entries.size(), dropped, errorCount, warningCount, tickCount, liveCount, started, mode, rendering.get());
    }
    public void setMode(String value) { mode = value; }
    public boolean isRendering() { return rendering.get(); }
    public void setRendering(boolean enabled) {
        rendering.set(enabled);
        add(Level.INFO, "RENDERER", enabled ? "RENDER_ON" : "RENDER_OFF", "Spielzustandsverarbeitung bleibt aktiv");
    }
    public record Stats(long buffered, long dropped, long errors, long warnings, long ticks, long liveEvents,
                        Instant started, String mode, boolean rendering) { }

    public static String sanitize(String input, int max) {
        if (input == null) return "";
        String safe = input.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ');
        safe = SECRET_FIELDS.matcher(safe).replaceAll("$1[REDACTED]");
        safe = EMAIL.matcher(safe).replaceAll("[REDACTED_EMAIL]");
        safe = safe.replaceAll("[\\p{Cntrl}&&[^ ]]", "?");
        if (safe.length() > max) safe = safe.substring(0, max) + "...[gekürzt]";
        return safe;
    }

    /** Copies latest entries in a compact, ChatGPT-friendly format. Never exports credentials. */
    public String clipboardReport() {
        Stats s = stats();
        List<Entry> lines = snapshot();
        final int maxLines = 1800;
        final int maxChars = 190000;
        int start = Math.max(0, lines.size() - maxLines);
        StringBuilder out = new StringBuilder(20000);
        out.append("OSRS DIAGNOSTICS | ").append(VERSION).append("\n")
            .append("Modus: ").append(s.mode()).append(" | Renderer: ").append(s.rendering() ? "AN" : "AUS").append("\n")
            .append("Events: ").append(s.buffered()).append(" | Ticks: ").append(s.ticks())
            .append(" | Warnungen: ").append(s.warnings()).append(" | Fehler: ").append(s.errors())
            .append(" | Externe Events: ").append(s.liveEvents()).append("\n")
            .append("Puffer-Überlauf: ").append(s.dropped()).append("\n")
            .append("Hinweis: Kein autonomer Spielclient. Keine Jagex-Verbindung. Keine Kontodaten übertragen.\n");
        if (start > 0) out.append("HINWEIS: Nur die letzten ").append(maxLines).append(" Ereignisse; ZIP enthält alle gepufferten.\n");
        var analysis = DiagnosticAnalyzer.analyze(s, lines);
        out.append("Warnungen: ").append(analysis.nonSimulatorWarnings())
            .append(" nicht simuliert / ").append(analysis.simulatorWarnings())
            .append(" künstlich\n");
        out.append("--- AUTOMATISCHE AUSWERTUNG ---\n");
        for (String finding : analysis.findings()) out.append("• ").append(finding).append('\n');
        out.append("--- LOG ---\n");
        for (int i = start; i < lines.size(); i++) {
            String line = lines.get(i).toLine();
            if (out.length() + line.length() + 3 > maxChars) {
                out.append("... Log für Zwischenablage gekürzt; vollständigen ZIP-Export verwenden.\n");
                break;
            }
            out.append(line).append('\n');
        }
        return out.toString();
    }

    public String completePlainLog() {
        StringBuilder out = new StringBuilder();
        for (Entry e : snapshot()) out.append(e.toLine()).append('\n');
        return out.toString();
    }

    public String jsonReport() {
        Stats s = stats();
        StringBuilder out = new StringBuilder(64000);
        out.append("{\n  \"schemaVersion\": 1,\n  \"clientVersion\": ").append(JsonUtil.quote(VERSION))
            .append(",\n  \"generatedAt\": ").append(JsonUtil.quote(Instant.now().toString()))
            .append(",\n  \"sessionStartedAt\": ").append(JsonUtil.quote(s.started().toString()))
            .append(",\n  \"mode\": ").append(JsonUtil.quote(s.mode()))
            .append(",\n  \"rendererEnabled\": ").append(s.rendering())
            .append(",\n  \"statistics\": {\"buffered\": ").append(s.buffered())
            .append(", \"dropped\": ").append(s.dropped())
            .append(", \"errors\": ").append(s.errors())
            .append(", \"warnings\": ").append(s.warnings())
            .append(", \"gameTicks\": ").append(s.ticks())
            .append(", \"externalEvents\": ").append(s.liveEvents()).append("},\n");
        var analysis = DiagnosticAnalyzer.analyze(s, snapshot());
        out.append("  \"analysis\": {\n    \"observedGameTicks\": ").append(analysis.observedGameTicks())
            .append(",\n    \"tickIntervals\": ").append(analysis.tickIntervals())
            .append(",\n    \"averageTickGapMs\": ").append(analysis.averageGapMs())
            .append(",\n    \"simulatorWarnings\": ").append(analysis.simulatorWarnings())
            .append(",\n    \"nonSimulatorWarnings\": ").append(analysis.nonSimulatorWarnings())
            .append(",\n    \"slowTickGaps\": ").append(analysis.slowGaps())
            .append(",\n    \"maxTickGapMs\": ").append(analysis.maxGapMs())
            .append(",\n    \"commonWarning\": ").append(JsonUtil.quote(analysis.mostFrequentWarning()))
            .append(",\n    \"findings\": [");
        for (int i = 0; i < analysis.findings().size(); i++) {
            if (i != 0) out.append(", ");
            out.append(JsonUtil.quote(analysis.findings().get(i)));
        }
        out.append("]\n  },\n  \"events\": [\n");
        List<Entry> entries = snapshot();
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            out.append("    {\"id\": ").append(e.id()).append(", \"timestamp\": ").append(JsonUtil.quote(e.at().toString()))
                .append(", \"level\": ").append(JsonUtil.quote(e.level().name()))
                .append(", \"source\": ").append(JsonUtil.quote(e.source()))
                .append(", \"event\": ").append(JsonUtil.quote(e.event()))
                .append(", \"detail\": ").append(JsonUtil.quote(e.detail())).append("}");
            if (i < entries.size() - 1) out.append(',');
            out.append('\n');
        }
        return out.append("  ]\n}\n").toString();
    }
}

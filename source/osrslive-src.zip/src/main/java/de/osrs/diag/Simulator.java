package de.osrs.diag;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

final class Simulator implements AutoCloseable {
    private final DiagnosticsCore core;
    private final Random random = new Random(1103);
    private ScheduledExecutorService timer;
    private int tick;
    private int x = 3200, y = 3200;
    private volatile boolean running;
    Simulator(DiagnosticsCore core) { this.core = core; }
    synchronized void start() {
        if (running) return;
        running = true;
        tick = 0;
        core.setMode("SIMULATION (keine OSRS-Verbindung)");
        core.add(DiagnosticsCore.Level.INFO, "SIMULATOR", "START", "Lokaler Testmodus, keine Verbindung zu Jagex");
        timer = Executors.newSingleThreadScheduledExecutor(r -> { Thread t = new Thread(r, "osrs-simulator"); t.setDaemon(true); return t; });
        timer.scheduleAtFixedRate(() -> {
            if (!running) return;
            try { onTick(); }
            catch (Exception ex) { core.add(DiagnosticsCore.Level.ERROR, "SIMULATOR", "TICK_FAILED", ex.getClass().getSimpleName()); }
        }, 0, 600, TimeUnit.MILLISECONDS);
    }
    private void onTick() {
        tick++;
        x += random.nextInt(3) - 1;
        y += random.nextInt(3) - 1;
        core.add(DiagnosticsCore.Level.DEBUG, "SIMULATOR", "GAME_TICK", "tick=" + tick + " x=" + x + " y=" + y + " plane=0");
        if (tick % 7 == 0) core.add(DiagnosticsCore.Level.INFO, "SIMULATOR", "NPC_SPAWNED", "npc_id=301 near=player");
        if (tick % 11 == 0) core.add(DiagnosticsCore.Level.INFO, "SIMULATOR", "INVENTORY_CHANGED", "slots_used=" + Math.min(28, tick / 11));
        if (tick % 19 == 0) core.add(DiagnosticsCore.Level.WARN, "SIMULATOR", "SIMULATED_DELAY", "Verzögerung erkannt: 1300ms (nur Beispiel)");
    }
    synchronized void stop() {
        if (!running) return;
        running = false;
        if (timer != null) { timer.shutdownNow(); timer = null; }
        core.setMode("NICHT VERBUNDEN");
        core.add(DiagnosticsCore.Level.INFO, "SIMULATOR", "STOP", "Testmodus angehalten");
    }
    synchronized boolean isRunning() { return running; }
    @Override public void close() { stop(); }
}

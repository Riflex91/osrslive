package de.osrs.diag;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Properties;
import java.io.StringReader;

/** Read-only GitHub release metadata checker; actual install runs in Windows launcher before Java starts. */
final class UpdateChecker {
    static final String MANIFEST = "https://raw.githubusercontent.com/Riflex91/osrslive/main/update-manifest.properties";
    record Info(String version, String jarUrl, String sha256) { }
    private UpdateChecker() { }
    static boolean isNewer(String candidate, String installed) {
        if (!candidate.matches("[0-9]+\\.[0-9]+\\.[0-9]+") ||
                !installed.matches("[0-9]+\\.[0-9]+\\.[0-9]+")) return false;
        String[] c = candidate.split("\\.");
        String[] i = installed.split("\\.");
        for (int x = 0; x < 3; x++) {
            long a = Long.parseLong(c[x]), b = Long.parseLong(i[x]);
            if (a != b) return a > b;
        }
        return false;
    }
    static boolean validJarUrl(String value) {
        return value != null && value.matches(
            "https://github\\.com/Riflex91/osrslive/releases/download/v[0-9]+\\.[0-9]+\\.[0-9]+/OSRS-Diagnostics-Client\\.jar");
    }
    static Info latest() throws Exception {
        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).followRedirects(HttpClient.Redirect.NORMAL).build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(MANIFEST)).timeout(Duration.ofSeconds(10))
                .header("User-Agent", "OSRS-Live-Diagnostics/" + DiagnosticsCore.VERSION).GET().build();
        HttpResponse<String> result = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (result.statusCode() != 200 || result.body().length() > 8192) throw new IllegalStateException("Ungültige Update-Antwort: " + result.statusCode());
        Properties properties = new Properties();
        properties.load(new StringReader(result.body()));
        String version = properties.getProperty("version", "");
        String url = properties.getProperty("jarUrl", "");
        String sha = properties.getProperty("jarSha256", "");
        if (!version.matches("[0-9]+\\.[0-9]+\\.[0-9]+") || !validJarUrl(url) || !sha.matches("(?i)[0-9a-f]{64}")) {
            throw new IllegalArgumentException("Update-Manifest ist ungültig");
        }
        return new Info(version, url, sha);
    }
}

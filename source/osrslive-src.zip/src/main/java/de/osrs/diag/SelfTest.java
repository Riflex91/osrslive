package de.osrs.diag;


final class SelfTest {
    private SelfTest() { }
    private static void require(boolean truth, String what) {
        if (!truth) throw new IllegalStateException("TEST FAILED: " + what);
        System.out.println("PASS " + what);
    }
    static void run() {
        try {
            DiagnosticsCore core = new DiagnosticsCore();
            core.add(DiagnosticsCore.Level.INFO,"TEST","START","password=pass123 token=abc123 person@example.com");
            String original = core.completePlainLog();
            require(!original.contains("pass123") && !original.contains("abc123") && !original.contains("person@example.com"),"privacy redaction");
            require(original.contains("[REDACTED]"),"redaction marker");
            String json = core.jsonReport();
            require(json.contains("\"schemaVersion\": 1") && json.contains("\"events\""),"valid diagnostic schema fields");
            require(core.clipboardReport().contains("TEST"),"clipboard includes unfiltered log");
            core.add(DiagnosticsCore.Level.WARN, "SIMULATOR", "SIMULATED_DELAY", "1300ms nur Beispiel");
            var classified = DiagnosticAnalyzer.analyze(core.stats(), core.snapshot());
            require(classified.simulatorWarnings() == 1 && classified.nonSimulatorWarnings() == 0,
                    "simulated delay is not a real failure");
            require(core.clipboardReport().contains("künstlich"), "clipboard distinguishes synthetic warnings");
            core.setRendering(false);
            require(core.stats().rendering() == false,"render mode independent");
            require(UpdateChecker.isNewer("0.2.1", "0.2.0"), "semantic newer version");
            require(!UpdateChecker.isNewer("0.2.0", "0.2.0"), "same version not newer");
            require(!UpdateChecker.isNewer("0.1.9", "0.2.0"), "older version rejected");
            require(UpdateChecker.validJarUrl("https://github.com/Riflex91/osrslive/releases/download/v0.2.1/OSRS-Diagnostics-Client.jar"), "valid release artifact URL");
            require(!UpdateChecker.validJarUrl("https://evil.example/test.jar"), "reject unapproved artifact origin");
            try (Simulator sim = new Simulator(core)) {
                sim.start(); Thread.sleep(1300); sim.stop();
                require(core.stats().ticks()>=3,"simulator generates actual timed ticks");
            }
            DiagnosticsCore metrics = new DiagnosticsCore();
            metrics.add(DiagnosticsCore.Level.DEBUG, "SIMULATOR", "GAME_TICK", "tick=1");
            Thread.sleep(30);
            metrics.add(DiagnosticsCore.Level.DEBUG, "SIMULATOR", "GAME_TICK", "tick=2");
            var measured = DiagnosticAnalyzer.analyze(metrics.stats(),metrics.snapshot());
            require(measured.tickIntervals() == 1 && measured.averageGapMs() >= 20,
                    "measured tick intervals are derived from actual timestamps");
            require(metrics.jsonReport().contains("averageTickGapMs"), "JSON includes timing metrics");
            System.out.println("ALL TESTS PASSED");
        } catch (Exception problem) {
            problem.printStackTrace();
            System.exit(1);
        }
    }
}

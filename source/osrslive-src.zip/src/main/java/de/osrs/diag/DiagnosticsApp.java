package de.osrs.diag;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Standalone Swing diagnostics console, independent of RuneLite/Jagex clients. */
public final class DiagnosticsApp {
    private final DiagnosticsCore core = new DiagnosticsCore();
    private final Simulator sim = new Simulator(core);
    private final JFrame frame = new JFrame("OSRS Live Diagnostics v" + DiagnosticsCore.VERSION);
    private final JTextArea logArea = new JTextArea();
    private final JComboBox<String> levelFilter = new JComboBox<>(new String[]{"ALLE", "INFO +", "WARN +", "NUR FEHLER"});
    private final JTextField search = new JTextField(16);
    private final JLabel status = new JLabel();
    private final JLabel stats = new JLabel();
    private final JLabel footer = new JLabel("Bereit");
    private final PreviewPanel preview = new PreviewPanel();
    private final JButton simulate = new JButton("Simulation starten");
    private final JButton updateButton = new JButton("Updates prüfen");
    private final JButton render = new JButton("Grafik ausschalten");
    private final JCheckBox pause = new JCheckBox("Ansicht pausieren");
    private final AtomicBoolean refreshQueued = new AtomicBoolean();

    private DiagnosticsApp() {
        core.addListener(event -> {
            if (refreshQueued.compareAndSet(false,true)) SwingUtilities.invokeLater(() -> {
                refreshQueued.set(false);
                if (!pause.isSelected()) renderLogs();
                updateStats();
                preview.repaint();
            });
        });
        createUi();
        core.add(DiagnosticsCore.Level.INFO, "CORE", "STARTED", "Version " + DiagnosticsCore.VERSION + " | Standalone, keine Jagex-Verbindung");
        core.add(DiagnosticsCore.Level.INFO, "CORE", "PRIVACY", "Keine Zugangsdaten oder Tokens im Export");
        updateStats();
    }
    private void createUi() {
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() { @Override public void windowClosing(java.awt.event.WindowEvent e) {
            sim.close(); frame.dispose();
        }});
        frame.setMinimumSize(new Dimension(870, 620));
        frame.setSize(1100, 780);
        frame.setLocationRelativeTo(null);
        JPanel root = new JPanel(new BorderLayout(0,12));
        root.setBorder(new EmptyBorder(16, 18, 14, 18));
        frame.setContentPane(root);

        JPanel top = new JPanel(new BorderLayout(0,12));
        JLabel title = new JLabel("OSRS LIVE DIAGNOSTICS  •  v" + DiagnosticsCore.VERSION + "  •  kein autonomer Bot");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 17f));
        top.add(title, BorderLayout.NORTH);
        JPanel indicators = new JPanel(new GridLayout(2,1,0,4));
        status.setFont(status.getFont().deriveFont(Font.BOLD, 13f));
        indicators.add(status);
        indicators.add(stats);
        top.add(indicators, BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 7, 3));
        actions.add(simulate); actions.add(render); actions.add(updateButton);
        JButton copy = new JButton("Log kopieren");
        copy.setFont(copy.getFont().deriveFont(Font.BOLD));
        actions.add(copy);
        JButton exportJson = new JButton("JSON exportieren");
        JButton exportZip = new JButton("ZIP exportieren");
        actions.add(exportJson); actions.add(exportZip);
        top.add(actions, BorderLayout.SOUTH);
        root.add(top, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(0,10));
        preview.setPreferredSize(new Dimension(0, 190));
        preview.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(120, 144, 165)), "Grafikvorschau (nur Visualisierung, nicht das OSRS-Spiel)", 0, 0, null, new Color(35, 64, 98)));
        center.add(preview, BorderLayout.NORTH);
        JPanel logContainer = new JPanel(new BorderLayout(0,7));
        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filters.add(new JLabel("Protokoll")); filters.add(levelFilter);
        filters.add(new JLabel("Suche:")); filters.add(search); filters.add(pause);
        JButton clear = new JButton("Puffer leeren"); filters.add(clear);
        logContainer.add(filters, BorderLayout.NORTH);
        logArea.setEditable(false);
        logArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        logArea.setBackground(new Color(17,24,39));
        logArea.setForeground(new Color(219,234,254));
        logArea.setCaretColor(Color.WHITE);
        logArea.setMargin(new Insets(9,11,9,11));
        logArea.setLineWrap(false);
        logContainer.add(new JScrollPane(logArea), BorderLayout.CENTER);
        center.add(logContainer, BorderLayout.CENTER);
        root.add(center, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout(0,5));
        JLabel note = new JLabel("Eigenständige Diagnoseanwendung ohne RuneLite. Keine Verbindung zum offiziellen OSRS. "+
                "„Log kopieren“ kopiert den gesamten aktuellen Diagnoseausschnitt (nicht nur den sichtbaren Filter).");
        note.setFont(note.getFont().deriveFont(11f));
        bottom.add(note, BorderLayout.NORTH);
        bottom.add(footer, BorderLayout.SOUTH);
        root.add(bottom, BorderLayout.SOUTH);

        simulate.addActionListener(e -> toggleSim());
        updateButton.addActionListener(e -> checkForUpdates());
        render.addActionListener(e -> { core.setRendering(!core.isRendering());
            render.setText(core.isRendering() ? "Grafik ausschalten" : "Grafik einschalten"); preview.setRenderingEnabled(core.isRendering()); preview.repaint(); });
        copy.addActionListener(e -> {
            try {
                String report = core.clipboardReport();
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(report), null);
                footer.setText("Log in Zwischenablage kopiert: " + report.length() + " Zeichen. Mit Strg+V hier im Chat einfügen.");
            } catch (IllegalStateException | HeadlessException exception) {
                core.add(DiagnosticsCore.Level.ERROR,"CLIPBOARD","COPY_FAILED",exception.getClass().getSimpleName());
                JOptionPane.showMessageDialog(frame,"Zwischenablage ist gerade nicht verfügbar. Bitte erneut versuchen.","Kopieren fehlgeschlagen",JOptionPane.ERROR_MESSAGE);
            }
        });
        exportJson.addActionListener(e -> exportFile(false));
        exportZip.addActionListener(e -> exportFile(true));
        clear.addActionListener(e -> { core.clear(); core.add(DiagnosticsCore.Level.INFO,"CORE","LOG_CLEARED","Puffer manuell geleert"); renderLogs(); updateStats(); });
        levelFilter.addActionListener(e -> renderLogs());
        search.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { renderLogs(); }
            public void removeUpdate(DocumentEvent e) { renderLogs(); }
            public void changedUpdate(DocumentEvent e) { renderLogs(); }
        });
        pause.addActionListener(e -> { if (!pause.isSelected()) renderLogs(); });
        frame.setVisible(true);
    }
    private void toggleSim() {
        if (sim.isRunning()) { sim.stop(); simulate.setText("Simulation starten"); return; }
        sim.start(); simulate.setText("Simulation stoppen");
    }
    private void checkForUpdates() {
        updateButton.setEnabled(false);
        footer.setText("Prüfe GitHub-Updatequelle ...");
        Thread worker = new Thread(() -> {
            try {
                UpdateChecker.Info info = UpdateChecker.latest();
                SwingUtilities.invokeLater(() -> {
                    updateButton.setEnabled(true);
                    if (UpdateChecker.isNewer(info.version(), DiagnosticsCore.VERSION)) {
                        core.add(DiagnosticsCore.Level.INFO, "UPDATER", "UPDATE_AVAILABLE", "Version " + info.version());
                        int answer = JOptionPane.showConfirmDialog(frame,
                            "Version " + info.version() + " ist verfügbar.\n"+
                            "Der Windows-Starter installiert geprüfte Updates beim nächsten Start.\n"+
                            "Möchtest du die Anwendung jetzt beenden?",
                            "Update verfügbar", JOptionPane.YES_NO_OPTION);
                        if (answer == JOptionPane.YES_OPTION) {
                            sim.close(); frame.dispose();
                        }
                    } else {
                        footer.setText("Version " + DiagnosticsCore.VERSION + " ist aktuell.");
                        JOptionPane.showMessageDialog(frame, "Keine neuere Version verfügbar.", "Update-Prüfung", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    updateButton.setEnabled(true);
                    footer.setText("Update-Prüfung fehlgeschlagen: " + ex.getClass().getSimpleName());
                    core.add(DiagnosticsCore.Level.WARN, "UPDATER", "CHECK_FAILED", ex.getClass().getSimpleName());
                });
            }
        }, "github-update-check");
        worker.setDaemon(true);
        worker.start();
    }
    private void renderLogs() {
        if (pause.isSelected()) return;
        List<DiagnosticsCore.Entry> all = core.snapshot();
        String needle = search.getText().toLowerCase(Locale.ROOT).trim();
        String level = (String) levelFilter.getSelectedItem();
        StringBuilder out = new StringBuilder();
        int start = Math.max(0, all.size() - 2000);
        for (int i = start; i < all.size(); i++) {
            DiagnosticsCore.Entry entry = all.get(i);
            if ("INFO +".equals(level) && entry.level().ordinal() < DiagnosticsCore.Level.INFO.ordinal()) continue;
            if ("WARN +".equals(level) && entry.level().ordinal() < DiagnosticsCore.Level.WARN.ordinal()) continue;
            if ("NUR FEHLER".equals(level) && entry.level() != DiagnosticsCore.Level.ERROR) continue;
            String line = entry.toLine();
            if (!needle.isEmpty() && !line.toLowerCase(Locale.ROOT).contains(needle)) continue;
            out.append(line).append('\n');
        }
        logArea.setText(out.toString());
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }
    private void updateStats() {
        DiagnosticsCore.Stats s = core.stats();
        status.setText("STATUS: " + s.mode() + "   |   Renderer " + (s.rendering()? "AN" : "AUS"));
        stats.setText("Ereignisse " + s.buffered() + "   •   Ticks " + s.ticks() +
                      "   •   Live " + s.liveEvents() + "   •   Warnungen " + s.warnings() +
                      "   •   Fehler " + s.errors() + "   •   Pufferverlust " + s.dropped());
    }
    private void exportFile(boolean zip) {
        JFileChooser chooser = new JFileChooser();
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        chooser.setSelectedFile(new java.io.File("osrs-diagnostics-" + stamp + (zip ? ".zip" : ".json")));
        if (chooser.showSaveDialog(frame) != JFileChooser.APPROVE_OPTION) return;
        Path path = chooser.getSelectedFile().toPath();
        if (!path.toString().toLowerCase(Locale.ROOT).endsWith(zip ? ".zip" : ".json")) path = Path.of(path + (zip ? ".zip" : ".json"));
        if (Files.exists(path) && JOptionPane.showConfirmDialog(frame,"Datei überschreiben?", "Bestätigen", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            if (zip) {
                try (ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(path), StandardCharsets.UTF_8)) {
                    zipText(out,"diagnostics.json",core.jsonReport());
                    zipText(out,"log.txt",core.completePlainLog());
                    zipText(out,"HINWEIS.txt", "OSRS Diagnostics v" + DiagnosticsCore.VERSION + "\n" +
                            "Diese Daten enthalten nur protokollierte Diagnoseereignisse.\n" +
                            "Prüfe die Datei vor dem Teilen. Keine Zugangsdaten oder Bridge-Schlüssel beifügen.\n");
                }
            } else Files.writeString(path,core.jsonReport(),StandardCharsets.UTF_8);
            footer.setText("Export gespeichert: " + path);
        } catch (IOException ex) {
            core.add(DiagnosticsCore.Level.ERROR,"EXPORT","SAVE_FAILED",ex.getClass().getSimpleName());
            JOptionPane.showMessageDialog(frame, "Datei konnte nicht gespeichert werden: " + ex.getMessage(),"Export-Fehler",JOptionPane.ERROR_MESSAGE);
        }
    }
    private static void zipText(ZipOutputStream out, String name, String text) throws IOException {
        out.putNextEntry(new ZipEntry(name));
        out.write(text.getBytes(StandardCharsets.UTF_8));
        out.closeEntry();
    }
    private static final class PreviewPanel extends JPanel {
        private int frameNo;
        private boolean renderingEnabled = true;
        void setRenderingEnabled(boolean enabled) { renderingEnabled = enabled; }
        PreviewPanel() { setBackground(new Color(27, 34, 47)); }
        @Override protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            try {
                if (!renderingEnabled) {
                    g.setColor(new Color(168, 186, 204));
                    g.drawString("Rendering AUS – Simulation / Diagnose laufen weiterhin", 20, Math.max(30, getHeight()/2));
                    return;
                }
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                int width = getWidth(), height = getHeight();
                g.setColor(new Color(47,59,70));
                for (int x = 16; x < width; x += 32) g.drawLine(x,15,x,height - 15);
                for (int y = 16; y < height; y += 32) g.drawLine(15,y,width - 15,y);
                int px = width / 2 + ((frameNo++ / 8) % 9 - 4) * 4;
                g.setColor(new Color(90,190,250)); g.fillOval(px - 10,height/2 - 10,20,20);
                g.setColor(new Color(245,186,90)); g.fillOval(px + 54,height/2 + 8,15,15);
                g.setColor(Color.WHITE);
                g.drawString("Diagnose-Vorschau / Platzhalter – keine echte OSRS-Grafik",20,35);
            } finally { g.dispose(); }
        }
    }
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("--self-test")) { SelfTest.run(); return; }
        StartupDiagnostics.record("STARTING", "Java=" + System.getProperty("java.version")
                + " | OS=" + System.getProperty("os.name")
                + " | AWT headless=" + GraphicsEnvironment.isHeadless());
        if (GraphicsEnvironment.isHeadless()) {
            System.err.println("Kein grafischer Windows-Desktop erkannt. Bitte nicht in einer Headless-Sitzung starten.");
            StartupDiagnostics.record("FAILED", "Kein grafischer Desktop erkannt");
            System.exit(2);
        }
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            System.err.println("[UNCAUGHT] " + thread.getName() + " " + error);
            error.printStackTrace(System.err);
            StartupDiagnostics.failure("UNCAUGHT_EXCEPTION", error);
        });
        SwingUtilities.invokeLater(() -> {
            try {
                DiagnosticsApp app = new DiagnosticsApp();
                if (!app.frame.isShowing()) throw new IllegalStateException("Das Hauptfenster wurde nicht sichtbar");
                StartupDiagnostics.record("READY", "Hauptfenster sichtbar | Version=" + DiagnosticsCore.VERSION);
                System.out.println("[READY] OSRS Diagnostics Client v" + DiagnosticsCore.VERSION + " Fenster sichtbar");
            } catch (Throwable failure) {
                StartupDiagnostics.failure("GUI_START_FAILED", failure);
                failure.printStackTrace(System.err);
                try {
                    JOptionPane.showMessageDialog(null,
                            "Die Diagnose-Oberflaeche konnte nicht gestartet werden.\n"
                            + "Bitte logs\\startup.log und logs\\startup-java.log pruefen.",
                            "OSRS Diagnostics - Startfehler", JOptionPane.ERROR_MESSAGE);
                } catch (Throwable ignored) { /* The graphical subsystem may itself be unavailable. */ }
                System.exit(1);
            }
        });
    }
}

package de.osrs.diag;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Pure, deterministic analysis; never treats simulated examples as real failures. */
final class DiagnosticAnalyzer {
    record Analysis(long observedGameTicks, long tickIntervals, long averageGapMs,
                    long slowGaps, long maxGapMs, long simulatorWarnings,
                    long nonSimulatorWarnings, String mostFrequentWarning, List<String> findings) { }
    private DiagnosticAnalyzer() { }
    static Analysis analyze(DiagnosticsCore.Stats stats, List<DiagnosticsCore.Entry> events) {
        Map<String, DiagnosticsCore.Entry> lastTickBySource = new HashMap<>();
        Set<String> tickSources = new HashSet<>();
        Map<String,Integer> nonSimWarnings = new HashMap<>();
        long ticks = 0, intervals = 0, totalGap = 0, slowGaps = 0, maxGap = 0;
        long syntheticWarnings = 0, realWarnings = 0;
        for (DiagnosticsCore.Entry event : events) {
            if (event.event().equals("GAME_TICK")) {
                ticks++;
                tickSources.add(event.source());
                DiagnosticsCore.Entry previous = lastTickBySource.put(event.source(), event);
                if (previous != null) {
                    long gap = java.time.Duration.between(previous.at(), event.at()).toMillis();
                    if (gap >= 0 && gap < 180_000) {
                        intervals++;
                        totalGap += gap;
                        maxGap = Math.max(maxGap, gap);
                        if (gap > 1200) slowGaps++;
                    }
                }
            }
            if (event.level() == DiagnosticsCore.Level.WARN) {
                if (event.source().equals("SIMULATOR") || event.event().startsWith("SIMULATED_")) {
                    syntheticWarnings++;
                } else {
                    realWarnings++;
                    nonSimWarnings.merge(event.event(), 1, Integer::sum);
                }
            }
        }
        String commonWarning = nonSimWarnings.entrySet().stream()
                .max(Comparator.<Map.Entry<String,Integer>>comparingInt(Map.Entry::getValue).thenComparing(Map.Entry::getKey))
                .map(e -> e.getKey() + " (" + e.getValue() + "×)").orElse("keine");
        ArrayList<String> findings = new ArrayList<>();
        if (stats.liveEvents() == 0) findings.add("Keine externen Adapter-Ereignisse empfangen; nur lokale Diagnosen möglich.");
        else findings.add(stats.liveEvents() + " externe Adapter-Ereignisse empfangen; Herkunft nicht verifiziert.");
        if (stats.errors() > 0) findings.add("Fehlereinträge erkannt: " + stats.errors() + ". ERROR-Ereignisse im Log prüfen.");
        else findings.add("Keine ERROR-Ereignisse im bisherigen Diagnosepuffer.");
        if (syntheticWarnings > 0) findings.add("Künstliche Simulatorwarnungen: " + syntheticWarnings + " (kein gemessener Laufzeitfehler).");
        if (realWarnings > 0) findings.add("Nicht-simulierte Warnungen: " + realWarnings + "; häufigste Kategorie: " + commonWarning + ".");
        if (intervals > 0) findings.add("Tick-Abstände: Ø " + Math.round((double)totalGap / intervals) + " ms, Maximum " + maxGap + " ms, " + intervals + " gemessene Intervalle.");
        if (slowGaps > 0) findings.add("Gemessene Ticklücken über 1200 ms: " + slowGaps + " (max. " + maxGap + " ms); Quelle und Ursache prüfen.");
        if (stats.dropped() > 0) findings.add("Logpuffer hat " + stats.dropped() + " ältere Einträge verworfen.");
        if (tickSources.size() == 1 && tickSources.contains("SIMULATOR")) findings.add("Alle Tick-Zeitstempel stammen aus der Simulation, nicht aus OSRS.");
        else if (tickSources.contains("SIMULATOR")) findings.add("Gemischte Tick-Quellen; Zeitabstände werden nur innerhalb gleicher Quellen berechnet.");
        if (events.size() < 5) findings.add("Wenig Daten: weitere Ereignisse erfassen, bevor Ursachen bewertet werden.");
        return new Analysis(ticks, intervals, intervals == 0 ? 0 : Math.round((double)totalGap / intervals),
                slowGaps, maxGap, syntheticWarnings, realWarnings, commonWarning, List.copyOf(findings));
    }
}

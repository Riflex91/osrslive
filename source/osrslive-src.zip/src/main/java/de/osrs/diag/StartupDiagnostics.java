package de.osrs.diag;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;

/** Best-effort startup breadcrumbs even if the Swing window cannot be displayed. */
public final class StartupDiagnostics {
    private static final Path DIR = Path.of("logs");
    private StartupDiagnostics() { }

    public static synchronized void record(String phase, String detail) {
        String line = Instant.now() + " [" + phase + "] " + DiagnosticsCore.sanitize(detail, 750) + System.lineSeparator();
        try {
            Files.createDirectories(DIR);
            Files.writeString(DIR.resolve("startup-java.log"), line, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("[STARTUP_LOG_WRITE_FAILED] " + e.getClass().getSimpleName());
        }
        System.out.print(line);
    }

    public static void failure(String phase, Throwable error) {
        record(phase, error.getClass().getName() + ": " + error.getMessage());
        StringWriter out = new StringWriter();
        error.printStackTrace(new PrintWriter(out));
        try {
            Files.createDirectories(DIR);
            Files.writeString(DIR.resolve("startup-java.log"),
                    DiagnosticsCore.sanitize(out.toString(), 20000) + System.lineSeparator(),
                    StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("[STARTUP_LOG_WRITE_FAILED] " + e.getClass().getSimpleName());
        }
    }
}

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Get-Command javac -ErrorAction SilentlyContinue)) { throw 'JDK 17 oder neuer erforderlich' }
$build = Join-Path $PSScriptRoot 'build/classes'
New-Item -ItemType Directory -Force -Path $build | Out-Null
$sources = @(Get-ChildItem -LiteralPath 'src/main/java' -Filter '*.java' -Recurse | ForEach-Object { $_.FullName })
& javac --release 17 -encoding UTF-8 -d $build @sources
if ($LASTEXITCODE -ne 0) { throw 'Kompilierung fehlgeschlagen' }
& jar --create --file 'OSRS-Diagnostics-Client.jar' --main-class de.osrs.diag.DiagnosticsApp -C $build .
if ($LASTEXITCODE -ne 0) { throw 'JAR-Erstellung fehlgeschlagen' }
& java -Djava.awt.headless=true -jar 'OSRS-Diagnostics-Client.jar' --self-test
if ($LASTEXITCODE -ne 0) { throw 'Selbsttests fehlgeschlagen' }

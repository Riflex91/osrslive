# OSRS Live Diagnostics v0.2.0

Eigenständige Java-17+-Diagnoseanwendung für Windows. **Kein RuneLite erforderlich.**

> Achtung: Diese Anwendung ist **kein offizieller OSRS-Spielclient**. Sie meldet sich nicht bei Jagex an und erhält keine Live-Spielinformationen. Die Grafikvorschau und die Spielereignisse sind simuliert. Keine Spielautomatisierung.

## Start

1. Gesamtes ZIP entpacken, nicht direkt aus ZIP starten.
2. `START-OSRS-Diagnostics.cmd` doppelklicken. Der Starter findet Java 17+ (idealerweise Java 21), obwohl eine ältere Java-Version im PATH stehen kann.
3. Der Starter sucht **bei jedem Programmstart** nach `update-manifest.properties` auf GitHub und installiert bei höherer Version nach Download, **SHA-256-Prüfung**, Selbsttest und Sicherung der alten JAR automatisch das Update. Bei Netzfehlern läuft die installierte Version weiter.
4. Im Programm kann `Updates prüfen` manuell nachsehen, ob ein Update vorliegt. Die eigentliche Installation erfolgt aus Sicherheitsgründen beim nächsten Start, wenn die JAR nicht in Verwendung ist.
5. `Simulation starten` → `Grafik ausschalten` → `Log kopieren` und hier `Strg+V` einfügen.

## GitHub-Updatekanal

- Repository: https://github.com/Riflex91/osrslive
- Manifest: https://raw.githubusercontent.com/Riflex91/osrslive/main/update-manifest.properties
- Artefakt: `https://github.com/Riflex91/osrslive/releases/download/vVERSION/OSRS-Diagnostics-Client.jar`
- Neu veröffentlichte Versionen brauchen ein Release mit dieser JAR und ein Manifest mit dem SHA-256.
- `logs/`, `backups/`, `VERSION.txt` bleiben lokal; nur die ausführbare JAR wird aktualisiert.

Die Windows-Update-Schritte sind in `UPDATE-OSRS-Diagnostics.ps1` implementiert. GitHub-Workflows bauen und veröffentlichen neue Versionen. In `logs/updater.log` und `logs/startup.log` stehen die Details. Alte JAR-Versionen bleiben im `backups/`-Ordner.

## Ursprüngliche Bridge

Die frühere lokale Bridge (Port 38941) diente ausschließlich dem passiven Empfang von Ereignissen anderer Programme, beispielsweise einer optionalen RuneLite-Erweiterung. Sie verband sich **nicht** mit Jagex. Für diese RuneLite-unabhängige Version wurde sie aus dem Programm entfernt. Eine echte OSRS-Spielanbindung ist weiterhin nicht vorhanden.

## Datenauswertung und Grenzen

- Diagnosekonsole, Filter, Export (ZIP/JSON), Zwischenablage, Game-Tick-Analyse und künstliche Verzögerungswarnungen bleiben erhalten.
- Der Renderer-Schalter betrifft nur die *eigene Vorschau*, nicht OSRS-Rendering.
- Die automatische Analyse kann simulierte Ereignisse nicht mit offiziellen Serverereignissen gleichsetzen.
- SHA-256 schützt gegen beschädigte/vertauschte Artefakte, **aber nicht gegen eine Übernahme des GitHub-Kontos oder des Update-Manifests**. Für höhere Sicherheitsanforderungen wären signierte Releases erforderlich.
- Für Windows-Build lokal `BUILD.ps1` ausführen; benötigt JDK 17+.

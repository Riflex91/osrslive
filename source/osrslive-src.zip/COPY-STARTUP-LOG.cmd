@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "logs" mkdir "logs" 2>nul
set "REPORT=logs\startup-report.txt"
> "%REPORT%" echo ===== OSRS Diagnostics STARTPROTOKOLL =====
>> "%REPORT%" echo Zeitpunkt: %DATE% %TIME%
>> "%REPORT%" echo ----- START-OSRS-Diagnostics.cmd -----
if exist "logs\startup.log" (type "logs\startup.log" >> "%REPORT%") else (>> "%REPORT%" echo Keine startup.log vorhanden.)
>> "%REPORT%" echo ----- JAVA UI START -----
if exist "logs\startup-java.log" (type "logs\startup-java.log" >> "%REPORT%") else (>> "%REPORT%" echo Keine startup-java.log vorhanden.)
>> "%REPORT%" echo ----- JAVA PATH -----
where java.exe >> "%REPORT%" 2>&1
>> "%REPORT%" echo ----- JAVA VERSION -----
java -version >> "%REPORT%" 2>&1
where clip.exe >nul 2>nul
if errorlevel 1 goto no_clip
type "%REPORT%" | clip.exe
if errorlevel 1 goto no_clip
echo.
echo Startprotokoll wurde in die Zwischenablage kopiert.
echo Jetzt im Chat STRG+V druecken.
echo.
pause
exit /b 0
:no_clip
echo Zwischenablage nicht verfuegbar. Bitte logs\startup-report.txt im Chat hochladen.
pause
exit /b 1

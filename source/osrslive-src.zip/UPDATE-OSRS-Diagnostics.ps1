param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$manifestUri = 'https://raw.githubusercontent.com/Riflex91/osrslive/main/update-manifest.properties'
$logDir = Join-Path $PSScriptRoot 'logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$logFile = Join-Path $logDir 'updater.log'
function Log([string]$message) {
    $line = "$(Get-Date -Format o) $message"
    Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
    Write-Host $message
}
try {
    $installedFile = Join-Path $PSScriptRoot 'VERSION.txt'
    $jarPath = Join-Path $PSScriptRoot 'OSRS-Diagnostics-Client.jar'
    if (-not (Test-Path -LiteralPath $installedFile) -or -not (Test-Path -LiteralPath $jarPath)) { throw 'Installation unvollständig: Version oder JAR fehlt' }
    $installed = (Get-Content -LiteralPath $installedFile -Raw).Trim()
    if ($installed -notmatch '^\d+\.\d+\.\d+$') { throw 'Installierte Versionsangabe ungültig' }
    $ProgressPreference = 'SilentlyContinue'
    $response = Invoke-WebRequest -Uri $manifestUri -UseBasicParsing -TimeoutSec 10 -Headers @{ 'Cache-Control'='no-cache'; 'User-Agent'='OSRS-Live-Diagnostics-Updater' }
    if ($response.StatusCode -ne 200 -or $response.Content.Length -gt 8192) { throw 'Update-Manifest nicht verfügbar oder zu groß' }
    $properties = @{}
    foreach ($line in ($response.Content -split "`n")) {
        if ($line -match '^\s*([a-zA-Z][a-zA-Z0-9]*)\s*=\s*(.*?)\s*$') { $properties[$Matches[1]] = $Matches[2] }
    }
    $remote = $properties['version']
    $jarUri = $properties['jarUrl']
    $sha256 = $properties['jarSha256']
    if ($remote -notmatch '^\d+\.\d+\.\d+$') { throw 'Manifest hat keine gültige Version' }
    $expectedUri = "https://github.com/Riflex91/osrslive/releases/download/v$remote/OSRS-Diagnostics-Client.jar"
    if ($jarUri -cne $expectedUri -or $sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw 'Manifest-Quelle oder Prüfsumme ungültig' }
    if ([version]$remote -le [version]$installed) { Log "Aktuelle Version: $installed (kein Update)"; exit 0 }
    if ($CheckOnly) { Log "Update verfügbar: $installed -> $remote"; exit 0 }
    if (-not $env:OSRS_JAVA_EXE -or -not (Test-Path -LiteralPath $env:OSRS_JAVA_EXE)) { throw 'Kompatible Java-Laufzeit nicht ermittelt' }
    $staging = Join-Path $PSScriptRoot '.update-stage'
    New-Item -ItemType Directory -Force -Path $staging | Out-Null
    $candidate = Join-Path $staging "candidate-$remote.jar"
    Log "Lade Update $remote von GitHub Releases ..."
    Invoke-WebRequest -Uri $jarUri -OutFile $candidate -UseBasicParsing -TimeoutSec 45 -Headers @{'User-Agent'='OSRS-Live-Diagnostics-Updater'}
    if ((Get-Item -LiteralPath $candidate).Length -gt 20971520) { throw 'JAR übersteigt Größenlimit (20 MiB)' }
    $actualSha = (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash
    if ($actualSha -ine $sha256) { throw 'SHA256-Prüfsumme stimmt nicht überein' }
    Log "Prüfsumme korrekt. Selbsttest für $remote ..."
    & $env:OSRS_JAVA_EXE '-Djava.awt.headless=true' '-jar' $candidate '--self-test' 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Selbsttest der Update-JAR fehlgeschlagen (Exitcode $LASTEXITCODE)" }
    $backupDir = Join-Path $PSScriptRoot 'backups'
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    $backupJar = Join-Path $backupDir "OSRS-Diagnostics-Client-$installed.jar"
    Copy-Item -LiteralPath $jarPath -Destination $backupJar -Force
    try {
        Copy-Item -LiteralPath $candidate -Destination $jarPath -Force
        Set-Content -LiteralPath $installedFile -Value $remote -Encoding Ascii
        Log "UPDATE_OK: $installed -> $remote"
    } catch {
        Copy-Item -LiteralPath $backupJar -Destination $jarPath -Force
        Set-Content -LiteralPath $installedFile -Value $installed -Encoding Ascii
        throw "UPDATE_ROLLBACK: $($_.Exception.Message)"
    }
    Remove-Item -LiteralPath $candidate -Force -ErrorAction SilentlyContinue
    exit 0
} catch {
    Log "UPDATE_FAILED: $($_.Exception.Message) | vorherige Version bleibt nutzbar"
    exit 1
}

# Output: absolute path to the newest detected Java >= 17, or exit 1.
# Runs entirely locally. Only stdout is consumed by the CMD launcher.
$ErrorActionPreference = 'SilentlyContinue'
$candidates = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
function Add-Candidate([string]$path) {
  if (-not [string]::IsNullOrWhiteSpace($path) -and (Test-Path -LiteralPath $path -PathType Leaf)) {
    [void]$candidates.Add((Resolve-Path -LiteralPath $path).Path)
  }
}
foreach ($base in @($env:JAVA_HOME, $env:JAVA_HOME_21_X64, $env:JAVA_HOME_17_X64)) {
  if ($base) { Add-Candidate (Join-Path $base 'bin\java.exe') }
}
# Enumerate common Temurin/Oracle/Microsoft/other JDK install paths independently of PATH.
foreach ($root in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
  if (-not $root) { continue }
  foreach ($vendor in @('Eclipse Adoptium', 'Microsoft', 'Java', 'Amazon Corretto', 'Zulu', 'BellSoft')) {
    $parent = Join-Path $root $vendor
    if (-not (Test-Path -LiteralPath $parent)) { continue }
    foreach ($folder in @(Get-ChildItem -LiteralPath $parent -Directory -ErrorAction SilentlyContinue)) {
      Add-Candidate (Join-Path $folder.FullName 'bin\java.exe')
    }
  }
}
foreach ($whereResult in @(where.exe java.exe 2>$null)) { Add-Candidate $whereResult }
$choices = @()
foreach ($candidate in $candidates) {
  $versionLine = (& $candidate -version 2>&1 | Out-String)
  if ($versionLine -notmatch 'version\s+"([^"]+)"') { continue }
  $versionString = $Matches[1]
  if ($versionString -match '^1\.(\d+)') { $major = [int]$Matches[1] }
  elseif ($versionString -match '^(\d+)') { $major = [int]$Matches[1] }
  else { continue }
  if ($major -ge 17) {
    $choices += [pscustomobject]@{ Path = $candidate; Major = $major }
  }
}
$best = $choices | Sort-Object -Property Major -Descending | Select-Object -First 1
if ($null -eq $best) { exit 1 }
Write-Output $best.Path
